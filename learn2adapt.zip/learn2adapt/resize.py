from torchvision import transforms
import cv2
from glob import glob
from PIL import Image
import os


img_path = '/media/qysun/CC84AC0B84ABF5DC/CityScapes/leftImg8bit_sequence_trainvaltest/leftImg8bit_sequence/*.png'
save_path = '/media/qysun/CC84AC0B84ABF5DC/CS/leftImg8bit_sequence_trainvaltest/leftImg8bit_sequence/'

img = cv2.imread(img_path)

print(img.shape)

self.resize[i] = transforms.Resize((self.height // s, self.width // s),
                                               interpolation=self.interp)