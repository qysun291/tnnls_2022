cat ./batch_dirs4.txt | while read line
do
echo $line
python3 evaluate_depth.py --load_weights_folder $line --eval_mono --data_path=/media/qysun/CC84AC0B84ABF5DC/kitti_data/
done
