import os

with open("aaa.txt", "w") as f:  
    for folder in os.train_images:
        for subfolder in os.train_images:
            for files in subfolder:
                f.write(files + str("\n"))
