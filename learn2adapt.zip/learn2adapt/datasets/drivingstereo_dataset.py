import collections
import glob
import os
import os.path as osp

import numpy as np
import torch
from PIL import Image
from PIL import ImageOps
from torch.utils import data
import random
import cv2
from torchvision import transforms


class DrivingStereoDataset(data.Dataset):
    def __init__(self, height, width, frame_idxs,
                 num_scales, root='./datasets', data_file='src_train.list',
                 phase='train'):
        self.root = root
        self.data_file = data_file
        self.files = []
        self.phase = phase

        self.height = height
        self.width = width
        self.num_scales = num_scales
        self.frame_idxs = frame_idxs
        self.interp = Image.ANTIALIAS

        self.K = np.array([[1.17, 0, 0.55, 0],
                           [0, 2.578, 0.75, 0],
                           [0, 0, 1, 0],
                           [0, 0, 0, 1]], dtype=np.float32)


        try:
            self.brightness = (0.8, 1.2)
            self.contrast = (0.8, 1.2)
            self.saturation = (0.8, 1.2)
            self.hue = (-0.1, 0.1)
            transforms.ColorJitter.get_params(
                self.brightness, self.contrast, self.saturation, self.hue)
        except TypeError:
            self.brightness = 0.2
            self.contrast = 0.2
            self.saturation = 0.2
            self.hue = 0.1

        self.resize = {}
        for i in range(self.num_scales):
            s = 2 ** i
            self.resize[i] = transforms.Resize((self.height // s, self.width // s),
                                               interpolation=self.interp)
        self.to_tensor = transforms.ToTensor()
        self.to_PIL = transforms.ToPILImage()

        with open(osp.join(self.root, self.data_file), 'r') as f:
            data_list = f.read().split('\n')
            for data in data_list:

                if len(data) == 0:
                    continue
                data_info = data.split(' ')                
                
                self.files.append({
                    "rgb": data_info[0]
                    })
                
                
                    
    def __len__(self):
        return len(self.files)
    
    def read_data(self, datafiles, get_depth=True):

        assert osp.exists(osp.join(self.root, datafiles['rgb'])), "Image does not exist"
        rgb = Image.open(osp.join(self.root, datafiles['rgb'])).convert('RGB')

        depth = None
        if get_depth == True:
            assert osp.exists(osp.join(self.root, datafiles['depth'])), "Depth does not exist"                
            depth = Image.open(osp.join(self.root, datafiles['depth']))           
    
        return rgb, depth
    
    # def get_filename(self, names, bias_index):
    #     ### rgb & depth
    #     filename = {}
    #     for key, name in names.items():
    #         (path, tmp_name) = osp.split(name)
    #         (cur_index, ext) = osp.splitext(tmp_name)
    #         filename[key] = "{}/{}{}".format(path, int(cur_index) + bias_index, ext)

    #     return filename

    def preprocess(self, inputs, color_aug):
        """Resize colour images to the required scales and augment if required

        We create the color_aug object in advance and apply the same augmentation to all
        images in this item. This ensures that all images input to the pose network receive the
        same augmentation.
        """
        for k in list(inputs):
            frame = inputs[k]
            if "color" in k:
                n, im, i = k
                for i in range(self.num_scales):
                    inputs[(n, im, i)] = self.resize[i](inputs[(n, im, i - 1)])

        for k in list(inputs):
            f = inputs[k]
            if "color" in k:
                n, im, i = k
                inputs[(n, im, i)] = self.to_tensor(f)
                inputs[(n + "_aug", im, i)] = self.to_tensor(color_aug(f))

    def check_filename(self, index):
        if not osp.exists(osp.join(self.root, self.files[index]['rgb'])):
            index = index - 2
            
        elif  not osp.exists(osp.join(self.root, self.files[index+1]['rgb'])):
            index = index - 1
            
        elif  not osp.exists(osp.join(self.root, self.files[index-1]['rgb'])):
            index = index + 1

        else:
            index = index
        
        return index
            
    def __getitem__(self, index):
        
        # if self.phase == 'train':
        #     index = random.randint(0, len(self)-1)
        if index > len(self) - 1:
            index = index % len(self)


        if self.phase == 'train' or self.phase == 'val': 
            index = self.check_filename(index)
            datafile_1 = self.files[index-1]    
            datafile_2 = self.files[index]
            datafile_3 = self.files[index+1]       
            datafiles = [datafile_1, datafile_2, datafile_3]
        elif self.phase == 'test':
            index = index
            datafiles = [self.files[index]]

        # print(datafiles)

        do_color_aug = self.phase == 'train' and random.random() > 0.5
        do_flip = self.phase == 'train' and random.random() > 0.5

        inputs = {}
        for scale in range(self.num_scales):
            K = self.K.copy()

            K[0, :] *= self.width // (2 ** scale)
            K[1, :] *= self.height // (2 ** scale)

            inv_K = np.linalg.pinv(K)

            inputs[("K", scale)] = torch.from_numpy(K)
            inputs[("inv_K", scale)] = torch.from_numpy(inv_K)
        
        for i, element in enumerate(datafiles):
            filename = datafiles[i]
            img, _ = self.read_data(filename, get_depth=False)

            if do_flip:
                img = img.transpose(Image.FLIP_LEFT_RIGHT)
            
            if self.phase == 'train' or self.phase == 'val': 
                inputs['color', i-1, -1] = img
            elif self.phase == 'test':
                inputs['color', i, -1] = img


            # if self.joint_transform is not None:
            #     if self.phase == 'train':    
            #         img, _, depth, _ = self.joint_transform((img, None, depth, self.phase, None))
            #     else:
            #         img, _, depth, _ = self.joint_transform((img, None, depth, 'test', None))

            # if self.img_transform is not None:
            #     img = self.img_transform(img)

            # test = self.to_tensor(depth)
            
            # inputs['color_aug', i, -1] = img
        
        if do_color_aug:
            color_aug = transforms.ColorJitter.get_params(
                self.brightness, self.contrast, self.saturation, self.hue)
        else:
            color_aug = (lambda x: x)

        self.preprocess(inputs, color_aug)

        for i in self.frame_idxs:
            del inputs[("color", i, -1)]
            del inputs[("color_aug", i, -1)]

        return inputs
        # if self.phase =='test':
        #     data = {}
        #     data['img'] = l_img
        #     data['depth'] = depth
        #     return data

        # data = {}
        # if img is not None:
        #     data['img'] = img
        # if depth is not None:
        #     data['depth'] = depth
        # return {'src': data}



