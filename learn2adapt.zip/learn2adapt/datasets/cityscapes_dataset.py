from __future__ import division
import json
import os
import numpy as np
import scipy.misc
import imageio
import random
from glob import glob
from torchvision import transforms
import torch
import torch.utils.data as data
from PIL import Image
from PIL import ImageOps
from .mono_dataset import MonoDataset

class CityScapesDataset(MonoDataset):
    def __init__(self, *args, split='train', **kwargs):
        super(CityScapesDataset, self).__init__(*args, **kwargs)

        self.full_res_shape = (2048, 1024)
        self.frames = self.collect_frames(split)
        self.sample_gap = 2
        self.seq_length = 3
        self.split = split

    def __len__(self):
        return len(self.frames)

    def __getitem__(self, index):
        """Returns a single training item from the dataset as a dictionary.

        Values correspond to torch tensors.
        Keys in the dictionary are either strings or tuples:

            ("color", <frame_id>, <scale>)          for raw colour images,
            ("color_aug", <frame_id>, <scale>)      for augmented colour images,
            ("K", scale) or ("inv_K", scale)        for camera intrinsics,
            "stereo_T"                              for camera extrinsics, and
            "depth_gt"                              for ground truth depth maps.

        <frame_id> is either:
            an integer (e.g. 0, -1, or 1) representing the temporal step relative to 'index',
        or
            "s" for the opposite image in the stereo pair.

        <scale> is an integer representing the scale of the image relative to the fullsize image:
            -1      images at native resolution as loaded from disk
            0       images resized to (self.width,      self.height     )
            1       images resized to (self.width // 2, self.height // 2)
            2       images resized to (self.width // 4, self.height // 4)
            3       images resized to (self.width // 8, self.height // 8)
        """

        if self.is_train == True:
            index = random.randint(0, len(self)-1)
        if index > len(self) - 1:
            index = index % len(self)
        inputs = {}

        do_color_aug = self.is_train and random.random() > 0.5
        do_flip = self.is_train and random.random() > 0.5

        

        tgt_frame_id = self.frames[index]
        city, snippet_id, tgt_local_frame_id, _ = tgt_frame_id.split('_')
        bias = self.is_valid_example(tgt_frame_id)
        if bias != 0:
            tgt_local_frame_id = '%.6d' % (int(tgt_local_frame_id) + bias) 

        
        for i in self.frame_idxs:
            curr_local_frame_id = '%.6d' % (int(tgt_local_frame_id) + i)
            curr_frame_id = '%s_%s_%s_' % (city, snippet_id, curr_local_frame_id)
            curr_image_file = os.path.join(self.data_path, 'leftImg8bit_sequence', 
                                self.split, city, curr_frame_id + 'leftImg8bit.jpg')
            curr_img = Image.open(curr_image_file).convert('RGB')

            inputs[("color", i, -1)] = curr_img

        # adjusting intrinsics to match each scale in the pyramid
        for scale in range(self.num_scales):
            intrinsics = self.load_intrinsics(tgt_frame_id, self.split)
            K_3x3 = intrinsics.copy()

            K = np.array([[0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [0, 0, 0, 1]], dtype=np.float32)

            K[:3,:3] = K_3x3


            K[0, :] /= 2048.0
            K[1, :] /= 1024.0

            K[0, :] *= self.width // (2 ** scale)
            K[1, :] *= self.height // (2 ** scale)

            inv_K = np.linalg.pinv(K)

            inputs[("K", scale)] = torch.from_numpy(K).to(torch.float32)
            inputs[("inv_K", scale)] = torch.from_numpy(inv_K).to(torch.float32)

        if do_color_aug:
            color_aug = transforms.ColorJitter.get_params(
                self.brightness, self.contrast, self.saturation, self.hue)
        else:
            color_aug = (lambda x: x)

        self.preprocess(inputs, color_aug)

        for i in self.frame_idxs:
            del inputs[("color", i, -1)]
            del inputs[("color_aug", i, -1)]

        return {'cs': inputs}
        
    def collect_frames(self, split):
        img_dir = self.data_path + '/leftImg8bit_sequence/' + split + '/'
        city_list = os.listdir(img_dir)
        frames = []
        for city in city_list:
            img_files = glob(img_dir + city + '/*.jpg')
            for f in img_files:
                frame_id = os.path.basename(f).split('leftImg8bit')[0]
                frames.append(frame_id)
        return frames

    # def get_train_example_with_idx(self, tgt_idx):
    #     tgt_frame_id = self.frames[tgt_idx]
    #     if not self.is_valid_example(tgt_frame_id):
    #         return False
    #     example = self.load_example(self.frames[tgt_idx])
    #     return example

    def load_intrinsics(self, frame_id, split):
        city, seq, _, _ = frame_id.split('_')
        camera_file = os.path.join(self.data_path, 'camera',
                                   split, city, city + '_' + seq + '_*_camera.json')
        camera_file = glob(camera_file)[0]
        with open(camera_file, 'r') as f: 
            camera = json.load(f)
        fx = camera['intrinsic']['fx']
        fy = camera['intrinsic']['fy']
        u0 = camera['intrinsic']['u0']
        v0 = camera['intrinsic']['v0']
        intrinsics = np.array([[fx, 0, u0],
                               [0, fy, v0],
                               [0,  0,  1]])
        return intrinsics

    def is_valid_example(self, tgt_frame_id):
        city, snippet_id, tgt_local_frame_id, _ = tgt_frame_id.split('_')
        for o in self.frame_idxs:
            curr_local_frame_id = '%.6d' % (int(tgt_local_frame_id) + o)
            curr_frame_id = '%s_%s_%s_' % (city, snippet_id, curr_local_frame_id)
            curr_image_file = os.path.join(self.data_path, 'leftImg8bit_sequence', 
                                self.split, city, curr_frame_id + 'leftImg8bit.jpg')
            if not os.path.exists(curr_image_file):
                return -o
        return 0

    def check_depth(self):
        return False