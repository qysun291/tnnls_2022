import collections
import glob
import os
import os.path as osp

import numpy as np
import torch
from PIL import Image
from PIL import ImageOps
import PIL.Image as pil
from torch.utils import data
import random
import cv2
from torchvision import transforms
from scipy import interpolate, io


class Make3dDataset(data.Dataset):
    def __init__(self, height, width):
        self.height = height
        self.width = width
        self.interp = Image.ANTIALIAS
        with open('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/train.txt', 'r') as f:
            test_filenames = f.read().splitlines()
        test_filenames = map(lambda x: x[4:-4], test_filenames)


        depths_gt = []
        self.images = []
        for filename in test_filenames:
            mat = io.loadmat(os.path.join('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/', "Train400Depth/",  "depth_sph_corr-{}.mat".format(filename)))
            depths_gt.append(mat["Position3DGrid"][:,:,3])
            self.depths_gt_cropped = list(map(lambda x: x[(55 - 21)//2:(55 + 21)//2], depths_gt))
            
            # image = Image.open(os.path.join('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/', "Train400_cropped/", "img-{}.jpg".format(filename))).convert('RGB')

            # image = cv2.imread(os.path.join('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/', "Train400_cropped/", "img-{}.jpg".format(filename)))
            # image = image[:,:,::-1].copy()
            # image = cv2.resize(image, (192, 640), interpolation=cv2.INTER_NEAREST)
            # image = torch.from_numpy(image)
            # self.images.append(image.permute(2, 0, 1))

            input_image = pil.open(os.path.join('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/Train400_cropped/',"img-{}.jpg".format(filename))).convert('RGB')
            original_width, original_height = input_image.size
            input_image = input_image.resize((self.width, self.height), pil.LANCZOS)
            input_image = transforms.ToTensor()(input_image)
            self.images.append(input_image)
            
    def read_data(self, datafiles, get_depth=True):

        assert osp.exists(osp.join(self.root, datafiles['rgb'])), "Image does not exist"
        rgb = Image.open(osp.join(self.root, datafiles['rgb'])).convert('RGB')

        depth = None
        if get_depth == True:
            assert osp.exists(osp.join(self.root, datafiles['depth'])), "Depth does not exist"                
            depth = Image.open(osp.join(self.root, datafiles['depth']))           
    
        return rgb, depth               
                    
    def __len__(self):
        return len(self.images)
            
    def __getitem__(self, index):
        inputs = {}
        inputs["color"] = self.images[index]
        inputs["depth_gt"] = self.depths_gt_cropped[index]
        return inputs