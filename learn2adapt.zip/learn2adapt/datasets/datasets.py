import collections
import glob
import os
import os.path as osp

import numpy as np
import torch
from PIL import Image
from PIL import ImageOps
from torch.utils import data
import random
import cv2

class ConcatDataset(torch.utils.data.Dataset):
    def __init__(self, *datasets):
        super(ConcatDataset, self).__init__()
        self.datasets = datasets

    def __getitem__(self, i):

        dd = {}
        {dd.update(d[i]) for d in self.datasets if d is not None}
        
        return dd

    def __len__(self):
        return max(len(d) for d in self.datasets if d is not None)
