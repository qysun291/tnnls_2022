import collections
import glob
import os
import os.path as osp

import numpy as np
import torch
from PIL import Image
from PIL import ImageOps
import PIL.Image as pil
from torch.utils import data
import random
import cv2
from torchvision import transforms
from scipy import interpolate, io


class Make3dDataset(data.Dataset):
    def __init__(self, height, width):
        self.height = height
        self.width = width
        self.interp = Image.ANTIALIAS
        self.files = []
        self.to_tensor = transforms.ToTensor()
        self.root = '/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/'

        try:
            self.brightness = (0.8, 1.2)
            self.contrast = (0.8, 1.2)
            self.saturation = (0.8, 1.2)
            self.hue = (-0.1, 0.1)
            transforms.ColorJitter.get_params(
                self.brightness, self.contrast, self.saturation, self.hue)
        except TypeError:
            self.brightness = 0.2
            self.contrast = 0.2
            self.saturation = 0.2
            self.hue = 0.1

        with open('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/train.txt', 'r') as f:
            test_filenames = f.read().splitlines()
        test_filenames = map(lambda x: x[4:-4], test_filenames)

        for filename in test_filenames:
            
            if len(filename) == 0:
                continue
                        
            
            self.files.append({
                "rgb": "img-{}.jpg".format(filename),
                "depth": "depth_sph_corr-{}.mat".format(filename)
                })




        # depths_gt = []
        # self.images = []
        # for filename in test_filenames:
        #     mat = io.loadmat(os.path.join('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/', "Train400Depth/",  "depth_sph_corr-{}.mat".format(filename)))
        #     depths_gt.append(mat["Position3DGrid"][:,:,3])
        #     self.depths_gt_cropped = list(map(lambda x: x[(55 - 21)//2:(55 + 21)//2], depths_gt))
        

        #     input_image = pil.open(os.path.join('/media/qysun/CC84AC0B84ABF5DC/TNNLS_2022/monodepth2_tnnls/Make3D/Train400_cropped/',"img-{}.jpg".format(filename))).convert('RGB')
        #     original_width, original_height = input_image.size
        #     input_image = input_image.resize((self.width, self.height), pil.LANCZOS)
        #     input_image = transforms.ToTensor()(input_image)
        #     self.images.append(input_image)
            
    def read_data(self, datafiles):

        assert osp.exists(osp.join(self.root, 'Train400_cropped',datafiles['rgb'])), "Image does not exist"
        rgb = Image.open(osp.join(self.root, 'Train400_cropped',datafiles['rgb'])).convert('RGB')
        rgb = transforms.Resize((self.height, self.width), interpolation=self.interp)(rgb)

        assert osp.exists(osp.join(self.root, 'Train400Depth', datafiles['depth'])), "Depth does not exist"   
        mat = io.loadmat(os.path.join(self.root, 'Train400Depth',  datafiles['depth']))
        depth = mat["Position3DGrid"][:,:,3][(55 - 21)//2:(55 + 21)//2]          
        return rgb, depth               
                    
    def __len__(self):
        return len(self.files)


    def __getitem__(self, index):

        datafiles = self.files[index]
        do_color_aug = random.random() > 0.5
        do_flip = random.random() > 0.5

        img, depth = self.read_data(datafiles)

        # if do_flip:
        #     img = img.transpose(Image.FLIP_LEFT_RIGHT)
        #     depth = depth.transpose(Image.FLIP_LEFT_RIGHT)                    

        if do_color_aug:
            color_aug = transforms.ColorJitter.get_params(
                self.brightness, self.contrast, self.saturation, self.hue)
            img = self.to_tensor(color_aug(img))
        else:
            img = self.to_tensor(img)
            # depth = self.to_tensor(depth)

        inputs = {}
        inputs["color"] = img
        inputs["depth_gt"] = depth
        return inputs