cat ./batch_dirs3.txt | while read line
do
echo $line
python3 evaluate_drivingstereo_depth.py --load_weights_folder $line --eval_mono 
done
