#!/usr/bin/env python3

"""
Demonstrates how to:
    * use the MAML wrapper for fast-adaptation,
    * use the benchmark interface to load Omniglot, and
    * sample tasks and split them in adaptation and evaluation sets.
"""

import random
import numpy as np
import torch
# import learn as l2l
import algorithms

from torch import nn, optim
from models import MonoDepth,MonoPose
# import networks
from data_vkitti import FewShotLearningDatasetParallel
from parser_utils import get_args
import torch.nn.functional as F
from layers import *

from torchviz import make_dot
import copy


def generate_images_pred(img1, pred_depth, pose, device, args):
    """Generate the warped (reprojected) color images for a minibatch.
    Generated images are saved into the `outputs` dictionary.
    """
    # self.opt = opt
    # self.gpu_ids = self.opt.gpu_ids
    # self.device = torch.device('cuda:{}'.format(self.gpu_ids[0])) if self.gpu_ids else torch.device('cpu')
    batchSize = int(args.num_samples_per_class/2)

    K = np.array([[0.58, 0, 0.5, 0],
                    [0, 1.92, 0.5, 0],
                    [0, 0, 1, 0],
                    [0, 0, 0, 1]], dtype=np.float32)
 
    # adjusting intrinsics to match each scale in the pyramid

    K = K.copy()

    K[0, :] *= img1.size()[3]
    K[1, :] *= img1.size()[2]

    inv_K = np.linalg.pinv(K)

    K = np.expand_dims(K, axis=0)
    inv_K = np.expand_dims(inv_K, axis=0)

    K = K.repeat(batchSize, 0)
    inv_K = inv_K.repeat(batchSize, 0)
    
    K = torch.from_numpy(K)
    inv_K = torch.from_numpy(inv_K)


    # disp = pred_depth
    _, depth = disp_to_depth(pred_depth, 0.1, 100.0)

    T = pose


    # K = self.K.copy()
    # inv_K = np.linalg.pinv(K)

    # K = torch.from_numpy(K)
    # inv_K= torch.from_numpy(inv_K)


    backproject_depth= BackprojectDepth(batchSize, img1.size()[2], img1.size()[3])
    # backproject_depth.to(device)

    project_3d = Project3D(batchSize, img1.size()[2], img1.size()[3])
    # project_3d.to(device)




    cam_points = backproject_depth(depth, inv_K, device)
    pix_coords = project_3d(cam_points, K, T, device)

    pred_image = F.grid_sample(img1, pix_coords, padding_mode="border")

    return pred_image


def compute_reprojection_loss( pred, target):
    """Computes reprojection loss between a batch of predicted and target images
    """
    abs_diff = torch.abs(target - pred)
    l1_loss = abs_diff.mean(1, True)

    ssim = SSIM()
    ssim_loss = ssim(pred, target).mean(1, True)
    reprojection_loss = 0.85 * ssim_loss + 0.15 * l1_loss

    return reprojection_loss


def disp_to_depth(disp, min_depth, max_depth):
    """Convert network's sigmoid output into depth prediction
    The formula for this conversion is given in the 'additional considerations'
    section of the paper.
    """
    min_disp = 1 / max_depth
    max_disp = 1 / min_depth
    scaled_disp = min_disp + (max_disp - min_disp) * disp
    depth = 1 / scaled_disp
    return scaled_disp, depth




def compute_errors(gt, pred):
    """Computation of error metrics between predicted and ground truth depths
    """

    gt = gt.cpu().detach().numpy()
    pred = pred.cpu().detach().numpy()
    thresh = np.maximum((gt / pred), (pred / gt))
    a1 = (thresh < 1.25     ).mean()
    a2 = (thresh < 1.25 ** 2).mean()
    a3 = (thresh < 1.25 ** 3).mean()

    rmse = (gt - pred) ** 2
    rmse = np.sqrt(rmse.mean())

    rmse_log = (np.log(gt) - np.log(pred)) ** 2
    rmse_log = np.sqrt(rmse_log.mean())

    abs_rel = np.mean(np.abs(gt - pred) / gt)

    sq_rel = np.mean(((gt - pred) ** 2) / gt)

    return abs_rel, sq_rel, rmse, rmse_log, a1, a2, a3


def scale_pyramid(img, num_scales):
    scaled_imgs = [img]

    s = img.size()

    h = s[2]
    w = s[3]

    for i in range(1, num_scales):
        ratio = 2**i
        nh = h // ratio
        nw = w // ratio
        scaled_img = F.upsample(img, size=(nh, nw), mode='nearest')
        scaled_imgs.append(scaled_img)

    scaled_imgs.reverse()
    return scaled_imgs


# def accuracy(predictions, targets):
#     predictions = predictions.argmax(dim=1).view(targets.shape)
#     return (predictions == targets).sum().float() / targets.size(0)


# def fast_adapt(batch, learner, loss, adaptation_steps, shots, ways, device):
def fast_adapt(batch, learner_depth, learner_pose, Sup_Depth_Loss, adaptation_steps, device, args):
    data, labels = batch
    data[0],data[1],data[2], labels = data[0].to(device),data[1].to(device),data[2].to(device), labels.to(device)

    # Separate data into adaptation/evalutation sets
    # 0 data[0]
    # 1 data[1]
    # 2 data[2]

    adaptation_indices = np.zeros(data[0].size(0), dtype=bool)
    adaptation_indices[np.arange(data[0].size(0)// 2) * 2 ] = True
    evaluation_indices = torch.from_numpy(~adaptation_indices)
    adaptation_indices = torch.from_numpy(adaptation_indices)


    adaptation_data, adaptation_labels = data[0][adaptation_indices], labels[adaptation_indices]
    evaluation_data, evaluation_labels = data[0][evaluation_indices], labels[evaluation_indices]

    adaptation_data_before, adaptation_data_after = data[1][adaptation_indices], data[2][adaptation_indices]
    evaluation_data_before, evaluation_data_after = data[1][evaluation_indices], data[2][evaluation_indices]

    adaptation_labels = scale_pyramid(adaptation_labels, 4)
    # evaluation_labels = scale_pyramid(evaluation_labels, 4)


    # adaptation_indices = np.zeros(data.size(0), dtype=bool)
    # adaptation_indices[np.arange(data.size(0)// 2) * 2 ] = True
    # evaluation_indices = torch.from_numpy(~adaptation_indices)
    # adaptation_indices = torch.from_numpy(adaptation_indices)
    # adaptation_data, adaptation_labels = data[adaptation_indices], labels[adaptation_indices]
    # evaluation_data, evaluation_labels = data[evaluation_indices], labels[evaluation_indices]

    # adaptation_labels = scale_pyramid(adaptation_labels, 4)

    # opt = optim.Adam(list(learner_depth.parameters()) + list(learner_pose.parameters()), 0.0001)
    
    # Adapt the model
    for step in range(adaptation_steps):
        

        train_pred_depths = learner_depth(adaptation_data)

        adaptation_data_pose_before = torch.cat([adaptation_data, adaptation_data_before], 1)
        axisangle_before, translation_before = learner_pose(adaptation_data_pose_before)
        train_preds_pose_before = transformation_from_parameters(axisangle_before[:, 0], translation_before[:, 0]) 

        adaptation_data_pose_after = torch.cat([adaptation_data, adaptation_data_after], 1)
        axisangle_after, translation_after  = learner_pose(adaptation_data_pose_after)
        train_preds_pose_after = transformation_from_parameters(axisangle_after[:, 0], translation_after[:, 0])

        train_pred_image_before = generate_images_pred(adaptation_data_before, train_pred_depths[3], train_preds_pose_before, device, args)
        train_pred_image_after = generate_images_pred(adaptation_data_after, train_pred_depths[3], train_preds_pose_after, device, args)

        train_reproject_loss = compute_reprojection_loss(adaptation_data, train_pred_image_before).mean() + compute_reprojection_loss(adaptation_data, train_pred_image_after).mean()

        train_depth_loss = 0

        for (train_pred_depth, adaptation_label) in zip(train_pred_depths, adaptation_labels):
            train_depth_loss += Sup_Depth_Loss(train_pred_depth, adaptation_label)

        # train_error = loss(learner(adaptation_data)[3], adaptation_labels)

        train_error =  train_reproject_loss + train_depth_loss
        # train_error =  train_depth_loss

        # train_error /= len(adaptation_data)


        learner_depth.adapt(train_error, allow_unused=True)
        learner_pose.adapt(train_error, allow_unused=True)

        # opt.zero_grad()
        # train_error.backward()
        # opt.step()  

   
        # learner_depth.adapt(train_error, allow_unused=True, allow_nograd=True)
        # learner_pose.adapt(train_error, allow_unused=True, allow_nograd=True)
        # train_abs = compute_errors(train_preds[3], adaptation_labels)

    
    # Evaluate the adapted model

    # evaluation_labels = scale_pyramid(evaluation_labels, 4)

    # valid_preds = learner(evaluation_data)

    # valid_error = 0

    # for (valid_pred, evaluation_label) in zip(valid_preds, evaluation_labels):
    #     valid_error += loss(valid_pred,evaluation_label)

    valid_pred_depths = learner_depth(evaluation_data)

    evaluation_data_pose_before = torch.cat([evaluation_data, evaluation_data_before], 1)
    axisangle_before, translation_before = learner_pose(evaluation_data_pose_before)
    valid_preds_pose_before = transformation_from_parameters(axisangle_before[:, 0], translation_before[:, 0]) 

    evaluation_data_pose_after = torch.cat([evaluation_data, evaluation_data_after], 1)
    axisangle_after, translation_after  = learner_pose(evaluation_data_pose_after)

    valid_preds_pose_after = transformation_from_parameters(axisangle_after[:, 0], translation_after[:, 0])

    valid_pred_image_before = generate_images_pred(evaluation_data, valid_pred_depths[3], valid_preds_pose_before, device, args)
    valid_pred_image_after = generate_images_pred(evaluation_data, valid_pred_depths[3], valid_preds_pose_after, device, args)

    valid_reproject_loss = compute_reprojection_loss(evaluation_data, valid_pred_image_before).mean() + compute_reprojection_loss(evaluation_data, valid_pred_image_after).mean()

    valid_depth_loss = 0

    # for (valid_pred_depth, evaluation_label) in zip(valid_pred_depths, evaluation_labels):
    #     valid_depth_loss += Sup_Depth_Loss(valid_pred_depth, evaluation_label)

    # # valid_error = loss(learner(evaluation_data)[3], evaluation_labels)
    # valid_error = 10 * valid_reproject_loss.mean() + valid_depth_loss.mean()

    # valid_error /= len(evaluation_data)


    valid_depth_loss = Sup_Depth_Loss(valid_pred_depths[3], evaluation_labels)

    # valid_error = loss(learner(evaluation_data)[3], evaluation_labels)

    valid_error = valid_reproject_loss + valid_depth_loss
    # valid_error =  valid_depth_loss

    # valid_error /= len(evaluation_data)

    # make_dot(valid_error)


    # valid_error /= len(evaluation_data)
    # valid_accuracy = accuracy(predictions_depth[3], evaluation_labels)

    pred = valid_pred_depths[3].clone()
    for i in range(evaluation_labels.size()[0]):
        ratio = torch.median(evaluation_labels[i]) / torch.median(pred[i])
        pred[i] *= ratio


    pred[pred < 0.001] = 0.001
    pred[pred > 0.999] = 0.999

    mask = evaluation_labels > 0
    pred = pred[mask]
    evaluation_labels = evaluation_labels[mask]

    valid_abs = compute_errors(evaluation_labels,pred)
    # valid_accuracy = accuracy(valid_preds, evaluation_labels)
    return valid_error,  valid_reproject_loss, valid_depth_loss, valid_abs



def main(
        # ways=5,
        # shots=1,
        # meta_lr=0.003,
        # fast_lr=0.5,
        meta_lr=0.0001,
        fast_lr=0.0001,
        meta_batch_size=4,
        adaptation_steps=1,
        num_iterations=60000,
        cuda=True,
        seed=42,
):

    args, device = get_args()
    dataset = FewShotLearningDatasetParallel(args=args)
    # batch = dataset.sample("train", 0)
    # batch = dataset.sample("val", 1)
    # batch = dataset.sample("test", 2)


    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    device = torch.device('cpu')
    if cuda:
        torch.cuda.manual_seed(seed)
        device = torch.device('cuda')

    # Load train/validation/test tasksets using the benchmark interface
    # tasksets = l2l.vision.benchmarks.get_tasksets('omniglot',
    #                                               train_ways=ways,
    #                                               train_samples=2*shots,
    #                                               test_ways=ways,
    #                                               test_samples=2*shots,
    #                                               num_tasks=20000,
    #                                               root='~/data',
    # )

    # Create model
    model_depth = MonoDepth(18, [0, 1, 2, 3], "pretrained")
    model_pose = MonoPose(18, [0, 1, 2, 3], "pretrained", 2, 1, 1)
    # model = networks.init_net(networks.UNetGenerator(norm='batch'), init_type='normal', gpu_ids='0')

    model_depth.to(device)
    maml_depth = algorithms.MAML(model_depth, lr=fast_lr, first_order=False)
    # maml_depth = l2l.algorithms.MAML(model_depth, lr=fast_lr, first_order=False)

    # opt_depth = optim.Adam(maml_depth.parameters(), meta_lr)

    model_pose.to(device)
    maml_pose = algorithms.MAML(model_pose, lr=fast_lr, first_order=False)
    # maml_pose = l2l.algorithms.MAML(model_pose, lr=fast_lr, first_order=False)

    # opt_pose = optim.Adam(maml_pose.parameters(), meta_lr)

    opt = optim.Adam(list(maml_depth.parameters()) + list(maml_pose.parameters()), meta_lr)

    Sup_Depth_Loss = nn.L1Loss()
    batch_id = 0
            

    for iteration in range(num_iterations):
        opt.zero_grad()
        # opt_depth.zero_grad()
        # opt_pose.zero_grad()
        meta_train_error = 0.0
        meta_train_reproject_loss = 0.0
        meta_train_depth_loss = 0.0
        meta_valid_error = 0.0
        meta_valid_accuracy = 0.0
        
        for task in range(meta_batch_size):
            # Compute meta-training loss
            # learner_depth = copy.deepcopy(maml_depth)
            # learner_pose = copy.deepcopy(maml_pose)
            learner_depth = maml_depth.clone()
            learner_pose = maml_pose.clone()

            # batch_id = np.random.randint(0,1000)
            batch_id += 1
            batch = dataset.sample("train", batch_id)

            # batch = dataset.sample("train", batch_id)
            # batch = tasksets.train.sample()
           
            evaluation_error, evaluation_reproject_loss, evaluation_depth_loss, evaluation_abs = fast_adapt(batch,
                                                               learner_depth,
                                                               learner_pose,
                                                               Sup_Depth_Loss,
                                                               adaptation_steps,
                                                            #    shots,
                                                            #    ways,
                                                               device,
                                                               args)
            evaluation_error.backward()
            meta_train_error += evaluation_error.item()
            meta_train_reproject_loss += evaluation_reproject_loss.item()
            meta_train_depth_loss += evaluation_depth_loss.item()
            # meta_train_accuracy += evaluation_accuracy.item()


            meta_train_accuracy_abs = np.array(evaluation_abs)

            # Compute meta-validation loss
            # learner_depth = copy.deepcopy(maml_depth)
            # learner_pose = copy.deepcopy(maml_pose)
            learner_depth = maml_depth.clone()
            learner_pose = maml_pose.clone()
            # batch = tasksets.validation.sample()
            # batch = dataset.sample("train", batch_id)
            batch = dataset.sample("val", batch_id)
            evaluation_error, evaluation_reproject_loss, evaluation_depth_loss, evaluation_abs2 = fast_adapt(batch,
                                                               learner_depth,
                                                               learner_pose,
                                                               Sup_Depth_Loss,
                                                               adaptation_steps,
                                                            #    shots,
                                                            #    ways,
                                                               device,
                                                               args)
            meta_valid_error += evaluation_error.item()
            # meta_valid_accuracy += evaluation_accuracy.item()
            meta_train_accuracy_abs2 = np.array(evaluation_abs2)

        # Print some metrics
        print('\n')
        print('Iteration', iteration)
        print('Meta Train Error', meta_train_error / meta_batch_size)
        print('Meta Depth Loss',  meta_train_depth_loss/ meta_batch_size)
        print('Meta Reprojection Loss', meta_train_reproject_loss / meta_batch_size)
        # print('Meta Train Accuracy', meta_train_accuracy / meta_batch_size)
        print('Meta Train Accuracy')
        print("\n  " + ("{:>8} | " * 7).format("abs_rel", "sq_rel", "rmse", "rmse_log", "a1", "a2", "a3"))
        print(("&{: 8.3f}  " * 7).format(*meta_train_accuracy_abs.tolist()) + "\\\\")

        print('Meta Valid Error', meta_valid_error / meta_batch_size)
        # print('Meta Valid Accuracy', meta_valid_accuracy / meta_batch_size)
        print('Meta Valid Accuracy')
        print("\n  " + ("{:>8} | " * 7).format("abs_rel", "sq_rel", "rmse", "rmse_log", "a1", "a2", "a3"))
        print(("&{: 8.3f}  " * 7).format(*meta_train_accuracy_abs2.tolist()) + "\\\\")
        


        # Average the accumulated gradients and optimize
        # count = 0
        # no_count = 0
        # dict1 =  maml.state_dict()

        for p in maml_depth.parameters():
            if p.grad is not None:
                # no_count += 1
                p.grad.data.mul_(1.0 / meta_batch_size)
        # opt.step()

        for p in maml_pose.parameters():
            if p.grad is not None:
                # no_count += 1
                p.grad.data.mul_(1.0 / meta_batch_size)
        opt.step()    

        # for p in maml_pose.parameters():
        #     if p.grad is not None:
        #         # no_count += 1
        #         p.grad.data.mul_(1.0 / meta_batch_size)
        # opt.step()       
    
    
    meta_test_error = 0.0
    meta_test_accuracy = 0.0
    for task in range(meta_batch_size):
        batch_id += 1
        # Compute meta-testing loss
        learner_depth = maml_depth.clone()
        learner_pose = maml_pose.clone()
        # batch = tasksets.test.sample()
        batch = dataset.sample("test", batch_id)
        evaluation_error, evaluation_accuracy = fast_adapt(batch,
                                                           learner_depth,
                                                           learner_pose,
                                                           Sup_Depth_Loss,
                                                           adaptation_steps,
                                                        #    shots,
                                                        #    ways,
                                                           device)
        meta_test_error += evaluation_error.item()
        meta_test_accuracy += evaluation_accuracy.item()
    print('Meta Test Error', meta_test_error / meta_batch_size)
    print('Meta Test Accuracy', meta_test_accuracy / meta_batch_size)


if __name__ == '__main__':
    main()
